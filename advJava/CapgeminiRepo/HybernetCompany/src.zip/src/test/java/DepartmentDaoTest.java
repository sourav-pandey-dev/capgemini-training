import org.junit.jupiter.api.Test;
import org.sachin.DepartmentDao;
import org.sachin.model.Department;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class DepartmentDaoTest {

    @Test
    public void getDepartment() {
        Department d = DepartmentDao.getDepartment(10);
        assertNotNull(d);
        System.out.println(d);
    }
    @Test
    public void testUpdateDepartment() {
        Department result = DepartmentDao.updateDepartment(10,
                new Department(10,"Admins",100));

        Department d = DepartmentDao.getDepartment(10);
        assertNotNull(result);
        assertNotNull(d);
        assertEquals(d.getDepartmentName(), result.getDepartmentName());
        System.out.println(result);
        System.out.println(d);
    }
}
